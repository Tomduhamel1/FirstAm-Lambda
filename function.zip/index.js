const AWS = require('aws-sdk');
const axios = require('axios');
const xml2js = require('xml2js');
const { v4: uuidv4 } = require('uuid');
const dynamoDB = new AWS.DynamoDB.DocumentClient();

const buildTitleServiceBlock = (
  titlePolicies,
  secondPolicies,
  endorsementProducts,
  noteAmount,
  salesAmount,
  effectiveDate,
  LoanPurposeType,
  stateCode
) => {
  let seq = 1;
  let xml = `<SERVICE SequenceNumber="${seq++}"><TITLE><TITLE_RESPONSE><TITLE_PRODUCTS><TITLE_PRODUCT><TITLE_POLICIES>`;

  // ✅ Owner's Policy – uses salesAmount
  if (titlePolicies.length) {
    xml += titlePolicies.map((p, i) => {
      const id = p['lvis:PolicyId'];
      const name = p['lvis:PolicyName'] || p['lvis:ProductName'];

      const defaultRateTypeId = p['lvis:DefaultRateTypeId'];
      const validRateTypes = p['lvis:ValidRateTypes']?.['lvis:KeyValue'];
      let rateType = 'Basic'; // fallback

      if (Array.isArray(validRateTypes)) {
        const match = validRateTypes.find(rt => rt['lvis:Key'] === defaultRateTypeId);
        if (match) rateType = match['lvis:Value'];
      } else if (validRateTypes?.['lvis:Key'] === defaultRateTypeId) {
        rateType = validRateTypes['lvis:Value'];
      }

      return `
        <TITLE_POLICY xlink:label="POLICY_${i + 1}" SequenceNumber="${i + 1}">
          <TITLE_POLICY_DETAIL>
            <TitleInsuranceAmount>${salesAmount}</TitleInsuranceAmount>
            <TitlePolicyEffectiveDate>${effectiveDate}</TitlePolicyEffectiveDate>
            <TitlePolicyIdentifier>${id}</TitlePolicyIdentifier>
            <EXTENSION><OTHER><lvis:TITLE_POLICY_DETAIL_EXTENSION>
              <lvis:ProductName>${name}</lvis:ProductName>
              <lvis:RateType>${rateType}</lvis:RateType>
            </lvis:TITLE_POLICY_DETAIL_EXTENSION></OTHER></EXTENSION>
          </TITLE_POLICY_DETAIL>
        </TITLE_POLICY>`;
    }).join('');
  }

  // ✅ Lender's Policy – uses noteAmount — SKIP if Cash Purchase
  if (secondPolicies.length && LoanPurposeType !== 'Cash Purchase') {
    xml += secondPolicies.map((p, i) => {
      const id = p['lvis:PolicyId'];
      const name = p['lvis:PolicyName'] || p['lvis:ProductName'];

      const defaultRateTypeId = p['lvis:DefaultRateTypeId'];
      const validRateTypes = p['lvis:ValidRateTypes']?.['lvis:KeyValue'];
      let rateType = 'Basic'; // fallback

      if (Array.isArray(validRateTypes)) {
        const match = validRateTypes.find(rt => rt['lvis:Key'] === defaultRateTypeId);
        if (match) rateType = match['lvis:Value'];
      } else if (validRateTypes?.['lvis:Key'] === defaultRateTypeId) {
        rateType = validRateTypes['lvis:Value'];
      }

      const matchingEndorsements = endorsementProducts.filter(e => e['lvis:ParentPolicyId'] === id);
      const endorsementsXML = matchingEndorsements.map((e, j) => `
        <TITLE_ENDORSEMENT xlink:label="POLICY_2_ENDR_${j + 1}" SequenceNumber="${j + 1}">
          <TitleEndorsementFormIdentifier>${e['lvis:ProductId']}</TitleEndorsementFormIdentifier>
          <TitleEndorsementFormName>${e['lvis:ProductName']}</TitleEndorsementFormName>
          <Concurrent_Endoresements />
        </TITLE_ENDORSEMENT>`).join('');

      return `
        <TITLE_POLICY xlink:label="POLICY_${i + 2}" SequenceNumber="${i + 2}">
          ${endorsementsXML ? `<TITLE_ENDORSEMENTS>${endorsementsXML}</TITLE_ENDORSEMENTS>` : ''}
          <TITLE_POLICY_DETAIL>
            <TitleInsuranceAmount>${noteAmount}</TitleInsuranceAmount>
            <TitlePolicyEffectiveDate>${effectiveDate}</TitlePolicyEffectiveDate>
            <TitlePolicyIdentifier>${id}</TitlePolicyIdentifier>
            <EXTENSION><OTHER><lvis:TITLE_POLICY_DETAIL_EXTENSION>
              <lvis:ProductName>${name}</lvis:ProductName>
              <lvis:RateType>${rateType}</lvis:RateType>
            </lvis:TITLE_POLICY_DETAIL_EXTENSION></OTHER></EXTENSION>
          </TITLE_POLICY_DETAIL>
        </TITLE_POLICY>`;
    }).join('');
  }

  xml += `</TITLE_POLICIES></TITLE_PRODUCT></TITLE_PRODUCTS></TITLE_RESPONSE></TITLE>`;
  xml += `<SERVICE_PRODUCT><SERVICE_PRODUCT_REQUEST><SERVICE_PRODUCT_DETAIL><ServiceProductDescription>TitlePolicy</ServiceProductDescription></SERVICE_PRODUCT_DETAIL></SERVICE_PRODUCT_REQUEST></SERVICE_PRODUCT>`;
  xml += `</SERVICE>`;

  return xml;
};

/*
const buildServiceBlock = (products, nameKey, blockLabel) => {
  if (!products || products.length === 0) return '';

  return products.map((p, i) => `
    <SERVICE SequenceNumber="${i + 2}">
      <SERVICE_PRODUCT>
        <SERVICE_PRODUCT_REQUEST>
          <SERVICE_PRODUCT_DETAIL>
            <ServiceProductDescription>${p[nameKey]}</ServiceProductDescription>
          </SERVICE_PRODUCT_DETAIL>
        </SERVICE_PRODUCT_REQUEST>
      </SERVICE_PRODUCT>
    </SERVICE>`).join('');
};
*/
function buildServiceBlock(productGroup, description, nameKey = 'lvis:ProductName', codeKey = 'lvis:ProductId', startingSeq = 2) {
  if (!Array.isArray(productGroup) || productGroup.length === 0) return { xml: '', nextSeq: startingSeq };

  let seq = startingSeq;
  const xml = productGroup.map((product, index) => {
    const name = getNested(product, Array.isArray(nameKey) ? nameKey : [nameKey])?.trim() || `Product_${index + 1}`;
    const code = getNested(product, Array.isArray(codeKey) ? codeKey : [codeKey])?.trim() || `CODE_${index + 1}`;
    const safeLabel = name.replace(/\s+/g, '_').replace(/[^\w\-]/g, '');

    return `
      <SERVICE SequenceNumber="${seq++}">
        <SERVICE_PRODUCT>
          <SERVICE_PRODUCT_REQUEST>
            <SERVICE_PRODUCT_DETAIL>
              <ServiceProductDescription>${description}</ServiceProductDescription>
            </SERVICE_PRODUCT_DETAIL>
            <SERVICE_PRODUCT_NAMES>
              <SERVICE_PRODUCT_NAME xlink:label="${safeLabel}_${index + 1}" SequenceNumber="1">
                <SERVICE_PRODUCT_NAME_DETAIL>
                  <ServiceProductNameDescription>${name}</ServiceProductNameDescription>
                  <ServiceProductNameIdentifier>${code}</ServiceProductNameIdentifier>
                </SERVICE_PRODUCT_NAME_DETAIL>
              </SERVICE_PRODUCT_NAME>
            </SERVICE_PRODUCT_NAMES>
          </SERVICE_PRODUCT_REQUEST>
        </SERVICE_PRODUCT>
      </SERVICE>`;
  }).join('');

  return { xml, nextSeq: seq };
}

function getNested(obj, pathArray) {
  return pathArray.reduce((acc, key) => acc?.[key], obj);
}

function getRateType(stateCode, loanPurposeType) {
  if (loanPurposeType === 'Refinance') {
    if (stateCode === 'PA') return 'Non-Sale';
    else if (stateCode === 'MD') return 'Residential Refinance';
    else if (stateCode === 'WI') return 'Residential Refinance (Model Loan)';
    else if (['WY', 'NE', 'IA'].includes(stateCode)) return 'Model Loan';
    else if (stateCode === 'TN') return 'Refinance/Property Already Owned';
    else if (stateCode === 'ME') return 'Refinance/Non-Purchase';
    else if (stateCode === 'CO') return 'Bundled Loan - Refinance';
    else if (stateCode === 'OK') return 'Refinance C';
    else if (stateCode === 'KY' || stateCode === 'CT' || stateCode === 'SC') return 'Refinance - Residential';
    else if (['AL', 'NV'].includes(stateCode)) return 'Residential Refinance';
    else return 'Refinance';
  } else {
    if (stateCode === 'PA') return 'Approved Attorney Procedure';
    else if (stateCode === 'NJ') return 'Standard';
    else if (['MO', 'TN'].includes(stateCode)) return 'Purchase Loan Policy';
    else return 'Basic';
  }
}

function buildRecordingServiceBlock(recordingProducts, salesAmount, startingSeq = 2) {
  if (!Array.isArray(recordingProducts) || recordingProducts.length === 0) return { xml: '', nextSeq: startingSeq };

  let seq = startingSeq;
  const xml = recordingProducts.map((p, i) => {
    const docName = p['lvis:DocName']?.trim() || 'Unknown Document';
    const docType = p['lvis:DocType'] || 'DEED';
    const pages = p['lvis:NumberOfPages'] || '1';
    const safeLabel = docName.replace(/\s+/g, '_').replace(/[^\w\-]/g, '');
    return `
<SERVICE SequenceNumber="${seq++}">
  <SERVICE_PRODUCT>
    <SERVICE_PRODUCT_REQUEST>
      <SERVICE_PRODUCT_DETAIL>
        <ServiceProductDescription>Recording</ServiceProductDescription>
      </SERVICE_PRODUCT_DETAIL>
      <SERVICE_PRODUCT_NAMES>
        <SERVICE_PRODUCT_NAME xlink:label="${safeLabel}_${i + 1}" SequenceNumber="1">
          <SERVICE_PRODUCT_NAME_DETAIL>
            <ServiceProductNameDescription>${docName}</ServiceProductNameDescription>
            <ServiceProductNameIdentifier>${docType}</ServiceProductNameIdentifier>
          </SERVICE_PRODUCT_NAME_DETAIL>
        </SERVICE_PRODUCT_NAME>
        <SERVICE_PRODUCT_NAME xlink:label="${safeLabel}_CONSIDERATION" SequenceNumber="2">
          <SERVICE_PRODUCT_NAME_DETAIL>
            <ServiceProductNameDescription>ConsiderationAmount</ServiceProductNameDescription>
            <ServiceProductNameIdentifier>${salesAmount}</ServiceProductNameIdentifier>
          </SERVICE_PRODUCT_NAME_DETAIL>
        </SERVICE_PRODUCT_NAME>
        <SERVICE_PRODUCT_NAME xlink:label="${safeLabel}_PAGES" SequenceNumber="3">
          <SERVICE_PRODUCT_NAME_DETAIL>
            <ServiceProductNameDescription>PageCount</ServiceProductNameDescription>
            <ServiceProductNameIdentifier>${pages}</ServiceProductNameIdentifier>
          </SERVICE_PRODUCT_NAME_DETAIL>
        </SERVICE_PRODUCT_NAME>
      </SERVICE_PRODUCT_NAMES>
    </SERVICE_PRODUCT_REQUEST>
  </SERVICE_PRODUCT>
</SERVICE>`;
  }).join('');

  return { xml, nextSeq: seq };
}

const clientId = 'ff4f2fdb-fe7d-430b-bb6c-8b95aae52f02';
const clientSecret = 'UCq8Q~2L-NdKVUvg2UC.5AYxMdAnqfO_UBoV0aOa';
const tenantId = '4cc65fd6-9c76-4871-a542-eb12a5a7800c';
const oauthUrl = `https://login.microsoftonline.com/${tenantId}/oauth2/v2.0/token`;
const scope = '58730ff7-91da-4e84-8155-59967e632e7d/.default';
const rateCalcGuideUrl = 'https://calculator.lvis.firstam.com/';

exports.handler = async (event) => {
    console.info('Received event:', JSON.stringify(event, null, 2));

    let requestBody;
    try {
        requestBody = JSON.parse(event.body);
        console.info('Parsed body:', requestBody);
    } catch (e) {
        console.error('Error parsing JSON:', e);
        return {
            statusCode: 400,
            body: JSON.stringify({ error: 'Invalid JSON format' }),
        };
    }

    const { PostalCode, SalesContractAmount, NoteAmount, LoanPurposeType } = requestBody;
    const normalizedZip = PostalCode.toString().padStart(5, '0');
    let noteAmount = Number(NoteAmount) === 0 ? 1000 : Number(NoteAmount);
let salesAmount = LoanPurposeType === 'Refinance' ? noteAmount : Number(SalesContractAmount);
let servicesBlock = '';
    if (!PostalCode) {
        console.error('Missing PostalCode parameter');
        return {
            statusCode: 400,
            body: JSON.stringify({ error: 'Missing or invalid PostalCode parameter' }),
        };
    }

    try {
        // Fetch OAuth token
        console.info('Fetching OAuth token...');
        const tokenResponse = await axios.post(oauthUrl, new URLSearchParams({
            grant_type: 'client_credentials',
            client_id: clientId,
            client_secret: clientSecret,
            scope: scope
        }));

        const token = tokenResponse.data.access_token;
        console.info('OAuth Token:', token);

        // Query DynamoDB for Zip Code data
        console.info('Querying DynamoDB for Zip Code data...');
        const zipCodeParams = {
            TableName: 'ZipCodes',
            Key: { zip: PostalCode }
        };
        
        const listParams = {
          TableName: 'ZipCodes',
          Limit: 1
        };
        
        try {
          const testScan = await dynamoDB.scan(listParams).promise();
          console.info('🔬 Table check result:', JSON.stringify(testScan));
        } catch (err) {
          console.error('❌ Table check failed:', err.message);
        }

        // ✅ Log full AWS identity and environment context
const sts = new AWS.STS();
const identity = await sts.getCallerIdentity().promise();

console.info('🔐 AWS Account ID:', identity.Account);
console.info('👤 Caller ARN:', identity.Arn);
console.info('📍 AWS Region:', AWS.config.region);
console.info('📦 DynamoDB Table Name: ZipCodes');
console.info('🗝️  DynamoDB Key:', { zip: PostalCode });

        const zipCodeData = await dynamoDB.get(zipCodeParams).promise();
        console.info('Zip Code Data:', zipCodeData);

        if (!zipCodeData.Item) {
            return {
                statusCode: 404,
                body: JSON.stringify({ error: 'Zip code not found' }),
            };
        }

        const { city, county_name: countyName, state_id: stateCode } = zipCodeData.Item;

// ✅ Normalize request fields for consistent casing
const loanPurposeType = LoanPurposeType;
const salesContractAmount = SalesContractAmount;
const transactionType = LoanPurposeType === 'Refinance' ? 'Refinance' : 'Sale w/ Mortgage';

const effectiveDate = new Date().toLocaleString('en-US', {
  timeZone: 'America/Los_Angeles',
  year: 'numeric',
  month: 'numeric',
  day: 'numeric',
  hour: 'numeric',
  minute: 'numeric',
  second: 'numeric',
  hour12: true
});

// ✅ Build the ProductList request XML
const buildProductListRequestXML = ({
  stateCode,
  countyName,
  city,
  transactionType,
  salesContractAmount,
  noteAmount,
  effectiveDate,
}) => {
  // Fix EffectiveDate format: remove commas if present
  const cleanEffectiveDate = effectiveDate.replace(',', '');

  return `<?xml version="1.0" encoding="utf-8"?>
<lvis:LVIS_XML xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:lvis="http://services.firstam.com/lvis/v2.0">
  <lvis:LVIS_HEADER>
    <lvis:LVISActionType>ProductList</lvis:LVISActionType>
    <lvis:ClientCustomerId>FNTE</lvis:ClientCustomerId>
    <lvis:ClientUniqueRequestId>CALC-${uuidv4()}</lvis:ClientUniqueRequestId>
  </lvis:LVIS_HEADER>
  <lvis:LVIS_CALCULATOR_TYPE_DATA_REQUEST>
    <lvis:LVIS_REQUEST_PARAMS>
      <lvis:LVIS_NAME_VALUE><lvis:Name>PropertyStateCode</lvis:Name><lvis:Value>${stateCode}</lvis:Value></lvis:LVIS_NAME_VALUE>
      <lvis:LVIS_NAME_VALUE><lvis:Name>PropertyCountyName</lvis:Name><lvis:Value>${countyName}</lvis:Value></lvis:LVIS_NAME_VALUE>
      <lvis:LVIS_NAME_VALUE><lvis:Name>PropertyCityName</lvis:Name><lvis:Value>${city}</lvis:Value></lvis:LVIS_NAME_VALUE>

      <!-- ✅ ADD THESE -->
      <lvis:LVIS_NAME_VALUE><lvis:Name>ClosingStateCode</lvis:Name><lvis:Value /></lvis:LVIS_NAME_VALUE>
      <lvis:LVIS_NAME_VALUE><lvis:Name>ClosingCountyName</lvis:Name><lvis:Value /></lvis:LVIS_NAME_VALUE>
      <lvis:LVIS_NAME_VALUE><lvis:Name>ClosingCityName</lvis:Name><lvis:Value /></lvis:LVIS_NAME_VALUE>

      <lvis:LVIS_NAME_VALUE><lvis:Name>TransactionType</lvis:Name><lvis:Value>${transactionType}</lvis:Value></lvis:LVIS_NAME_VALUE>
      <lvis:LVIS_NAME_VALUE><lvis:Name>SalesAmount</lvis:Name><lvis:Value>${salesContractAmount}</lvis:Value></lvis:LVIS_NAME_VALUE>
      <lvis:LVIS_NAME_VALUE><lvis:Name>LoanAmount</lvis:Name><lvis:Value>${noteAmount}</lvis:Value></lvis:LVIS_NAME_VALUE>
      <lvis:LVIS_NAME_VALUE><lvis:Name>EffectiveDate</lvis:Name><lvis:Value>${cleanEffectiveDate}</lvis:Value></lvis:LVIS_NAME_VALUE>
      <lvis:LVIS_NAME_VALUE><lvis:Name>PropertyType</lvis:Name><lvis:Value>Residential</lvis:Value></lvis:LVIS_NAME_VALUE>

      <!-- ✅ THESE SIX ARE NOW CORRECT -->
      <lvis:LVIS_NAME_VALUE><lvis:Name>IsTitle</lvis:Name><lvis:Value>True</lvis:Value></lvis:LVIS_NAME_VALUE>
      <lvis:LVIS_NAME_VALUE><lvis:Name>IsClosing</lvis:Name><lvis:Value>True</lvis:Value></lvis:LVIS_NAME_VALUE>
      <lvis:LVIS_NAME_VALUE><lvis:Name>IsRecording</lvis:Name><lvis:Value>True</lvis:Value></lvis:LVIS_NAME_VALUE>
      <lvis:LVIS_NAME_VALUE><lvis:Name>IsEndorsements</lvis:Name><lvis:Value>True</lvis:Value></lvis:LVIS_NAME_VALUE>
    </lvis:LVIS_REQUEST_PARAMS>
  </lvis:LVIS_CALCULATOR_TYPE_DATA_REQUEST>
</lvis:LVIS_XML>`;
};

// ✅ Send ProductList request and parse results
let servicesBlock = '';
try {
  const productListRequestXML = buildProductListRequestXML({
    stateCode,
    countyName,
    city,
    transactionType,
    salesContractAmount,
    noteAmount,
    effectiveDate,
  });

  console.info('📄 ProductList Request XML:\n', productListRequestXML);

  const productListResponse = await axios.post(
    'https://calculator.lvis.firstam.com/ProductList',
    productListRequestXML,
    {
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/xml',
      },
    }
  );

console.info("📦 ProductList raw XML response:\n", productListResponse.data);

  const parsedProductList = await xml2js.parseStringPromise(productListResponse.data, {
    explicitArray: false,
    ignoreAttrs: false,
  });

  const responseBody = parsedProductList?.['lvis:LVIS_XML']?.['lvis:LVIS_CALCULATOR_TYPE_DATA_RESPONSE']?.['lvis:CalcTypeData'];
  const productList = responseBody?.['lvis:ProductsList'];

  if (!productList) {
    console.error("❌ No valid ProductsList found in ProductList response. Keys:", Object.keys(responseBody || {}));
    throw new Error('❌ No valid ProductsList found in ProductList response');
  }

  console.info("🔍 Parsed ProductList structure (keys):", Object.keys(productList));
  console.log('🧾 Raw Closing Products:', productList['lvis:SettlementProduct']);
  console.log('🧾 Raw Recording Products:', productList['lvis:RecordingProduct']);
  console.log('🧾 Raw Other Products:', productList['lvis:OtherProduct']);

  const parseSettlementProducts = (closingCostsRaw) => {
    if (!closingCostsRaw) return [];
  
    const closingCosts = Array.isArray(closingCostsRaw) ? closingCostsRaw : [closingCostsRaw];
    const defaultClosingCost = closingCosts.find(c => c['lvis:IsDefault'] === 'true');
    if (!defaultClosingCost) {
      console.warn('⚠️ No default ClosingCost found in ProductList.');
      return [];
    }
  
    const includedFees = defaultClosingCost['lvis:IncludedFees']?.['lvis:ClosingFee'];
    if (!includedFees) {
      console.warn('⚠️ No IncludedFees found in default ClosingCost.');
      return [];
    }
  
    const fees = Array.isArray(includedFees) ? includedFees : [includedFees];
    return fees
      .filter(fee => fee['lvis:Name'] && fee['lvis:Id'])  // ✅ Ensure valid data
      .map(fee => ({
        lvis: {
          ProductName: fee['lvis:Name'],
          ProductId: fee['lvis:Id']
        }
      }));
  };

  const getEnabledProducts = (group) => {
    if (!group) return [];
    const products = Array.isArray(group) ? group : [group];
    return products.filter(p => p['lvis:IsDefault'] === 'true');
  };

// ✅ Extract enabled products from ProductList response
const titlePolicies = getEnabledProducts(productList['lvis:PolicyProducts']?.['lvis:PolicyProduct']);
const rawSecondPolicies = productList['lvis:SecondPolicyProducts']?.['lvis:PolicyProduct'];
const secondPolicies = getEnabledProducts(rawSecondPolicies);
const lenderPolicies = secondPolicies.length > 0 ? secondPolicies : titlePolicies;
const endorsementProducts = getEnabledProducts(productList['lvis:Endorsements']?.['lvis:Endorsement']);

// ✅ Handle Settlement Products (correctly from ClosingCosts section)
const closingCostsRaw = productList['lvis:ClosingCosts']?.['lvis:ClosingCost'];
console.log('🧾 Raw Closing Costs:', closingCostsRaw);
const closingProducts = parseSettlementProducts(closingCostsRaw);

console.log('✅ Parsed Settlement Products:', closingProducts.map(p => p.lvis.ProductName));

// ✅ Handle Recording Products
const recordingProductsRaw = productList['lvis:RecordingDocTypes']?.['lvis:RecordingDocType'];
console.log('🧾 Raw Recording Products:', recordingProductsRaw);
const recordingProducts = (Array.isArray(recordingProductsRaw) ? recordingProductsRaw : [recordingProductsRaw])
  .filter(p => p?.['lvis:IsDefault'] === 'true');

  console.log('📄 Parsed Recording Products:', JSON.stringify(recordingProducts, null, 2));

// ✅ Handle Other Products
const otherProductsRaw = productList['lvis:OtherProducts']?.['lvis:Product'];
console.log('🧾 Raw Other Products:', otherProductsRaw);
const otherProducts = (Array.isArray(otherProductsRaw) ? otherProductsRaw : [otherProductsRaw])
  .filter(p => p?.['lvis:IsDefault'] === 'true');

// ✅ Log enabled product names
console.log('✅ Enabled Title Policies:', titlePolicies.map(p => p['lvis:PolicyName']));
console.log('✅ Enabled Endorsements:', endorsementProducts.map(p => p['lvis:ProductName']));
console.log('✅ Enabled Closing Products:', closingProducts.map(p => p['lvis:ProductName'] || p['lvis:DocName']));
console.log('✅ Enabled Recording Products:', recordingProducts.map(p => p['lvis:ProductName'] || p['lvis:DocName']));
console.log('✅ Enabled Other Products:', otherProducts.map(p => p['lvis:ProductName']));

let currentSeq = 1;
let servicesParts = [];

// Title block (always Sequence 1)
servicesParts.push(
  buildTitleServiceBlock(
    titlePolicies,
    lenderPolicies,
    endorsementProducts,
    noteAmount,
    salesAmount,
    new Date().toISOString().split('T')[0],
    LoanPurposeType, // <== ADD THIS
    stateCode
  )
);

// Settlement (Closing) Products — TEMPORARILY DISABLED to prevent API failures
/*
if (closingProducts.length > 0) {
  const closingProductsSafe = closingProducts.filter(
    p => !['3127', '3091'].includes(p.lvis?.ProductId)
  );
  if (closingProductsSafe.length > 0) {
    const { xml, nextSeq } = buildServiceBlock(
      closingProductsSafe,
      'Settlement',
      ['lvis', 'ProductName'],
      ['lvis', 'ProductId'],
      currentSeq + 1
    );
    servicesParts.push(xml);
    currentSeq = nextSeq - 1;
  }
}
*/

// Recording Products
if (recordingProducts.length > 0) {
  const { xml, nextSeq } = buildRecordingServiceBlock(recordingProducts, salesAmount, currentSeq + 1);
  servicesParts.push(xml);
  currentSeq = nextSeq - 1;
}

// Other Products
if (otherProducts.length > 0) {
  const { xml, nextSeq } = buildServiceBlock(otherProducts, 'Other', 'lvis:ProductName', 'lvis:ProductId', currentSeq + 1);
  servicesParts.push(xml);
  currentSeq = nextSeq - 1;
}

servicesBlock = servicesParts.join('');

} catch (err) {
  console.error("❌ Failed ProductList block:", err.message || err);
}

        // Query DynamoDB for State Fee data
        console.info('Querying DynamoDB for State Fee data...');
        const stateFeeParams = {
            TableName: 'FNTEFees',
            Key: { StateCode: stateCode }
        };

        const stateFeeData = await dynamoDB.get(stateFeeParams).promise();
        console.info('State Fee Response:', stateFeeData);

        if (!stateFeeData.Item) {
            return {
                statusCode: 404,
                body: JSON.stringify({ error: 'State fees not found' }),
            };
        }

        const { SettlementFee } = stateFeeData.Item;
        
        const clientUniqueRequestId = uuidv4();


// Prepare the XML request for RateCalcGuide API
const requestXML = `
<lvis:LVIS_XML xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:lvis="http://services.firstam.com/lvis/v2.0">
  <lvis:LVIS_HEADER>
    <lvis:LVISActionType>RateCalc</lvis:LVISActionType>
    <lvis:ClientCustomerId>FNTE</lvis:ClientCustomerId>
    <lvis:ClientUniqueRequestId>${clientUniqueRequestId}</lvis:ClientUniqueRequestId>
  </lvis:LVIS_HEADER>
  <lvis:LVIS_CALCULATOR_REQUEST>
    <lvis:EffectiveDate>2024-07-03</lvis:EffectiveDate>
    <lvis:IsGenerateDocument>false</lvis:IsGenerateDocument>
    <lvis:MISMO_XML>
      <MESSAGE MISMOReferenceModelIdentifier="3.4.0" xmlns="http://www.mismo.org/residential/2009/schemas">
        <ABOUT_VERSIONS>
          <ABOUT_VERSION>
            <CreatedDatetime>2024-07-03T17:01:51.761242-08:00</CreatedDatetime>
            <DataVersionIdentifier>1.1.0</DataVersionIdentifier>
            <DataVersionName>LenderSimulator</DataVersionName>
          </ABOUT_VERSION>
        </ABOUT_VERSIONS>
        <DEAL_SETS>
          <DEAL_SET>
            <DEALS>
              <DEAL>
                <COLLATERALS>
                  <COLLATERAL SequenceNumber="1">
                    <SUBJECT_PROPERTY>
                      <ADDRESS>
                        <AddressAdditionalLineText>Unit 3</AddressAdditionalLineText>
                        <AddressLineText>123 Main St</AddressLineText>
                        <CityName>${city}</CityName>
                        <CountyName>${countyName}</CountyName>
                        <StateCode>${stateCode}</StateCode>
                      </ADDRESS>
                      <SALES_CONTRACTS>
                        <SALES_CONTRACT>
                          <SALES_CONTRACT_DETAIL>
                            <SalesContractAmount>${LoanPurposeType === 'Refinance' ? (Number(NoteAmount) === 0 ? 1000 : NoteAmount) : SalesContractAmount}</SalesContractAmount>
                          </SALES_CONTRACT_DETAIL>
                        </SALES_CONTRACT>
                      </SALES_CONTRACTS>
                      <SITE>
                        <SITE_LOCATIONS>
                          <SITE_LOCATION>
                            <LocationType>Residential</LocationType>
                          </SITE_LOCATION>
                        </SITE_LOCATIONS>
                      </SITE>
                    </SUBJECT_PROPERTY>
                  </COLLATERAL>
                </COLLATERALS>
                <LOANS>
                  <LOAN xlink:label="SubjectLoan" SequenceNumber="1">
                    <LOAN_IDENTIFIERS>
                      <LOAN_IDENTIFIER SequenceNumber="1">
                        <LoanIdentifier>1234567</LoanIdentifier>
                        <LoanIdentifierType>LenderLoan</LoanIdentifierType>
                      </LOAN_IDENTIFIER>
                    </LOAN_IDENTIFIERS>
                    <TERMS_OF_LOAN>
                      ${LoanPurposeType === 'Refinance' ? `
                        <LoanPurposeType>Refinance</LoanPurposeType>
                        <NoteAmount>${Number(NoteAmount) === 0 ? 1000 : NoteAmount}</NoteAmount>
                      ` : `
                        <LoanPurposeType>Other</LoanPurposeType>
                        <LoanPurposeTypeOtherDescription>Sale w/ Mortgage</LoanPurposeTypeOtherDescription>
                        <NoteAmount>${Number(NoteAmount) === 0 ? 1000 : NoteAmount}</NoteAmount>
                      `}
                    </TERMS_OF_LOAN>
                  </LOAN>
                </LOANS>
                <SERVICES>
                ${servicesBlock}
                </SERVICES>
              </DEAL>
            </DEALS>
          </DEAL_SET>
        </DEAL_SETS>
      </MESSAGE>
    </lvis:MISMO_XML>
  </lvis:LVIS_CALCULATOR_REQUEST>
</lvis:LVIS_XML>`;

console.log('Generated XML:', requestXML);



        // Log the XML request
        console.info('XML Request:', requestXML);

        // Call the RateCalcGuide API with OAuth token
        console.info('Calling RateCalcGuide API...');
        const rateCalcGuideResponse = await axios.post(rateCalcGuideUrl, requestXML, {
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/xml'
            }
        });

        // Log the XML response
        console.info('RateCalcGuide API Response:', rateCalcGuideResponse.data);

        // Parse the XML response
        const parser = new xml2js.Parser();
        const parsedResponse = await parser.parseStringPromise(rateCalcGuideResponse.data);
        if (
            !parsedResponse['lvis:LVIS_XML'] || 
            !parsedResponse['lvis:LVIS_XML']['lvis:LVIS_CALCULATOR_RESPONSE'] || 
            !parsedResponse['lvis:LVIS_XML']['lvis:LVIS_CALCULATOR_RESPONSE'][0]['lvis:MISMO_XML'] || 
            !parsedResponse['lvis:LVIS_XML']['lvis:LVIS_CALCULATOR_RESPONSE'][0]['lvis:MISMO_XML'][0]['MESSAGE'] || 
            !parsedResponse['lvis:LVIS_XML']['lvis:LVIS_CALCULATOR_RESPONSE'][0]['lvis:MISMO_XML'][0]['MESSAGE'][0]['DEAL_SETS'] || 
            !parsedResponse['lvis:LVIS_XML']['lvis:LVIS_CALCULATOR_RESPONSE'][0]['lvis:MISMO_XML'][0]['MESSAGE'][0]['DEAL_SETS'][0]['DEAL_SET'] || 
            !parsedResponse['lvis:LVIS_XML']['lvis:LVIS_CALCULATOR_RESPONSE'][0]['lvis:MISMO_XML'][0]['MESSAGE'][0]['DEAL_SETS'][0]['DEAL_SET'][0]['DEALS'] || 
            !parsedResponse['lvis:LVIS_XML']['lvis:LVIS_CALCULATOR_RESPONSE'][0]['lvis:MISMO_XML'][0]['MESSAGE'][0]['DEAL_SETS'][0]['DEAL_SET'][0]['DEALS'][0]['DEAL'] || 
            !parsedResponse['lvis:LVIS_XML']['lvis:LVIS_CALCULATOR_RESPONSE'][0]['lvis:MISMO_XML'][0]['MESSAGE'][0]['DEAL_SETS'][0]['DEAL_SET'][0]['DEALS'][0]['DEAL'][0]['LOANS'] || 
            !parsedResponse['lvis:LVIS_XML']['lvis:LVIS_CALCULATOR_RESPONSE'][0]['lvis:MISMO_XML'][0]['MESSAGE'][0]['DEAL_SETS'][0]['DEAL_SET'][0]['DEALS'][0]['DEAL'][0]['LOANS'][0]['LOAN'] || 
            !parsedResponse['lvis:LVIS_XML']['lvis:LVIS_CALCULATOR_RESPONSE'][0]['lvis:MISMO_XML'][0]['MESSAGE'][0]['DEAL_SETS'][0]['DEAL_SET'][0]['DEALS'][0]['DEAL'][0]['LOANS'][0]['LOAN'][0]['FEE_INFORMATION'] || 
            !parsedResponse['lvis:LVIS_XML']['lvis:LVIS_CALCULATOR_RESPONSE'][0]['lvis:MISMO_XML'][0]['MESSAGE'][0]['DEAL_SETS'][0]['DEAL_SET'][0]['DEALS'][0]['DEAL'][0]['LOANS'][0]['LOAN'][0]['FEE_INFORMATION'][0]['FEES'][0]
        ) {
            throw new Error('Unexpected response structure');
        }

const fees = parsedResponse['lvis:LVIS_XML']['lvis:LVIS_CALCULATOR_RESPONSE'][0]['lvis:MISMO_XML'][0]['MESSAGE'][0]['DEAL_SETS'][0]['DEAL_SET'][0]['DEALS'][0]['DEAL'][0]['LOANS'][0]['LOAN'][0]['FEE_INFORMATION'][0]['FEES'][0]['FEE'];
const loanComments = parsedResponse['lvis:LVIS_XML']['lvis:LVIS_CALCULATOR_RESPONSE'][0]['lvis:MISMO_XML'][0]['MESSAGE'][0]['DEAL_SETS'][0]['DEAL_SET'][0]['DEALS'][0]['DEAL'][0]['LOANS'][0]['LOAN'][0]['LOAN_COMMENTS'][0]['LOAN_COMMENT'];

// Log all fee descriptions
fees.forEach(fee => {
    console.info('Fee Description:', fee['FEE_DETAIL'][0]['FeeDescription'][0]);
});

const extractFees = (feeArray, description) => {
    const feeObj = feeArray.find(fee => fee['FEE_DETAIL'][0]['FeeDescription'][0] === description);
    if (!feeObj) return { BuyerFee: '0.0', SellerFee: '0.0' };

    console.info(`Extracting fees for: ${description}`);
    console.info('Fee Object:', JSON.stringify(feeObj, null, 2));

    const feePayments = feeObj['FEE_PAYMENTS'][0]['FEE_PAYMENT'];

    const getPaymentAmount = (payment, type, useEstimated) => {
        const amount = useEstimated 
            ? parseFloat(payment['FeeEstimatedPaymentAmount'][0]) || 0.0
            : parseFloat(payment['FeeActualPaymentAmount'][0]) || 0.0;
        console.info(`Payment Amount for ${type} (UseEstimated=${useEstimated}): ${amount}`);
        return amount;
    };

    const buyerFee = feePayments.find(payment => payment['$']['SequenceNumber'] === '3')
        ? getPaymentAmount(feePayments.find(payment => payment['$']['SequenceNumber'] === '3'), 'Buyer', true)
        : getPaymentAmount(feePayments.find(payment => payment['$']['SequenceNumber'] === '1'), 'Buyer', false);

    const sellerFee = feePayments.find(payment => payment['$']['SequenceNumber'] === '4')
        ? getPaymentAmount(feePayments.find(payment => payment['$']['SequenceNumber'] === '4'), 'Seller', true)
        : getPaymentAmount(feePayments.find(payment => payment['$']['SequenceNumber'] === '2'), 'Seller', false);

    return {
        BuyerFee: buyerFee || '0.0',
        SellerFee: sellerFee || '0.0'
    };
};

const findSpecificFee = (feeArray, label) => {
    const feeObj = feeArray.find(fee => fee['$']['xlink:label'] === label);
    if (!feeObj) return { BuyerFee: '0.0', SellerFee: '0.0' };

    console.info(`Extracting fees for label: ${label}`);
    console.info('Fee Object:', JSON.stringify(feeObj, null, 2));

    const feePayments = feeObj['FEE_PAYMENTS'][0]['FEE_PAYMENT'];

    const getPaymentAmount = (payment, type, useEstimated) => {
        const amount = useEstimated 
            ? parseFloat(payment['FeeEstimatedPaymentAmount'][0]) || 0.0
            : parseFloat(payment['FeeActualPaymentAmount'][0]) || 0.0;
        console.info(`Payment Amount for ${type} (UseEstimated=${useEstimated}): ${amount}`);
        return amount;
    };

    const buyerFee = feePayments.find(payment => payment['$']['SequenceNumber'] === '3')
        ? getPaymentAmount(feePayments.find(payment => payment['$']['SequenceNumber'] === '3'), 'Buyer', true)
        : getPaymentAmount(feePayments.find(payment => payment['$']['SequenceNumber'] === '1'), 'Buyer', false);

    const sellerFee = feePayments.find(payment => payment['$']['SequenceNumber'] === '4')
        ? getPaymentAmount(feePayments.find(payment => payment['$']['SequenceNumber'] === '4'), 'Seller', true)
        : getPaymentAmount(feePayments.find(payment => payment['$']['SequenceNumber'] === '2'), 'Seller', false);

    return {
        BuyerFee: buyerFee || '0.0',
        SellerFee: sellerFee || '0.0'
    };
};



        const extractRecordingFees = (feeArray) => {
            const recordingFees = feeArray.filter(fee => fee['FEE_DETAIL'][0]['FeeDescription'][0] === 'RecordingFee');
            return recordingFees.map(fee => {
                const feePayments = fee['FEE_PAYMENTS'][0]['FEE_PAYMENT'];
                const buyerFee = feePayments.find(payment => payment['FeePaymentPaidByType'][0] === 'Buyer');
                const sellerFee = feePayments.find(payment => payment['FeePaymentPaidByType'][0] === 'Seller');

                return {
                    FeeDescription: fee['FEE_DETAIL'][0]['FeeDescription'][0],
                    DisclosureItemName: fee['FEE_DETAIL'][0]['DisclosureItemName'][0],
                    BuyerFee: buyerFee ? buyerFee['FeeActualPaymentAmount'][0] : '0.0',
                    SellerFee: sellerFee ? sellerFee['FeeActualPaymentAmount'][0] : '0.0'
                };
            });
        };

        const extractTransferTaxFees = (feeArray) => {
            const transferTaxFees = feeArray.filter(fee => fee['FEE_DETAIL'][0]['FeeDescription'][0] === 'TransferTax');
            return transferTaxFees.map(fee => {
                const feePayments = fee['FEE_PAYMENTS'][0]['FEE_PAYMENT'];
                const buyerFee = feePayments.find(payment => payment['FeePaymentPaidByType'][0] === 'Buyer');
                const sellerFee = feePayments.find(payment => payment['FeePaymentPaidByType'][0] === 'Seller');

                return {
                    FeeDescription: fee['FEE_DETAIL'][0]['FeeDescription'][0],
                    DisclosureItemName: fee['FEE_DETAIL'][0]['DisclosureItemName'][0],
                    BuyerFee: buyerFee ? buyerFee['FeeActualPaymentAmount'][0] : '0.0',
                    SellerFee: sellerFee ? sellerFee['FeeActualPaymentAmount'][0] : '0.0'
                };
            });
        };

        // Extract required fees
// Extract required fees
const eaglePolicyFees = LoanPurposeType === 'Refinance' ? { BuyerFee: '0.0', SellerFee: '0.0' } : findSpecificFee(fees, "FEE_POLICY_1");

// Use FEE_POLICY_1 for Refinance, otherwise use FEE_POLICY_2
const altaLoanPolicyFees = LoanPurposeType === 'Refinance' ? findSpecificFee(fees, "FEE_POLICY_1") : findSpecificFee(fees, "FEE_POLICY_2");


        const settlementFees = LoanPurposeType === 'Refinance'
        ? {
            BuyerFee: (stateFeeData.Item?.SettlementFeeRefi || 0).toString(),
            SellerFee: '0.0'
          }
        : {
            BuyerFee: (stateFeeData.Item?.SettlementFee || 0).toString(),
            SellerFee: '0.0'
          };
        const eaglePolicyTaxFees = LoanPurposeType === 'Refinance' ? { BuyerFee: '0.0', SellerFee: '0.0' } : findSpecificFee(fees, "FEE_POLICY_1_SALES_TAX_1");
        const altaLoanPolicyTaxFees = findSpecificFee(fees, "FEE_POLICY_2_SALES_TAX_1");
        let recordingFees = extractRecordingFees(fees);
        let transferTaxFees = extractTransferTaxFees(fees);

       // Exclude certain fees for Refinance LoanPurposeType
        if (LoanPurposeType === 'Refinance' || LoanPurposeType === '$Refinance') {
            recordingFees = recordingFees.filter(fee => fee.DisclosureItemName !== 'Conveyance Deed - State Transfer NY Tax');
            transferTaxFees = transferTaxFees.filter(fee => fee.DisclosureItemName !== 'Conveyance Deed - State Transfer NY Tax');
        }
        
        // Prepare the extracted fees array
              let extractedFees = [
    {
        FeeDescription: "Title - Owner's Title Insurance",
        ...eaglePolicyFees
    },
    {
        FeeDescription: "Title - Lender's Title Insurance",
        ...altaLoanPolicyFees
    },
    {
        FeeDescription: 'Title - Settlement Fee',
        ...settlementFees
    },
    {
        FeeDescription: "Title - Sales Tax - Owner's Title Insurance",
        ...eaglePolicyTaxFees
    },
    {
        FeeDescription: "Title - Sales Tax - Lender's Title Insurance",
        ...altaLoanPolicyTaxFees
    },
    ...recordingFees,
    ...transferTaxFees
];


        
        // Calculate and add Agricultural Tax if applicable
        if (
          (PostalCode === '02801' || PostalCode === '02837') &&
          ['purchase', 'cash purchase'].includes(LoanPurposeType.toLowerCase())
        ) {
          if (SalesContractAmount > 450000) {
            const agriculturalTax = (SalesContractAmount - 450000) * 0.04;
            console.info('Calculated Agricultural Tax:', agriculturalTax.toFixed(2));
            extractedFees.push({
              FeeDescription: 'Agricultural Tax',
              BuyerFee: agriculturalTax.toFixed(2),
              SellerFee: '0.0'
            });
          }
        }

        // Detailed logging for Sales Tax fees extraction
        console.info('Eagle Policy Tax Fees:', JSON.stringify(eaglePolicyTaxFees, null, 2));
        console.info('ALTA Loan Policy Tax Fees:', JSON.stringify(altaLoanPolicyTaxFees, null, 2));
        console.info('Recording Fees:', JSON.stringify(recordingFees, null, 2));
        console.info('Transfer Tax Fees:', JSON.stringify(transferTaxFees, null, 2));

        // Add additional state-specific fees from FNTEFees table, excluding 0 or null fees
        const stateFeeTitles = {
            SettlementFee: 'Title - Settlement Fee',
            ShortFormPolicy: 'Title - Short Form Policy',
            CountersignLender: 'Title - Countersign Lender',
            CountersignOwner: 'Title - Countersign Owner',
            NotaryFee: 'Title - Notary Fee',
            JudgementSearch: 'Title - Judgement Search',
            AttorneyFee: 'Title - Attorney Fee',
            AbstractorTitleSearch: 'Title - Abstractor Title Search',
            SearchFee: 'Title - Search Fee',
            ExamFee: 'Title - Exam Fee',
            AbstractCopyFee: 'Title - Abstract Copy Fee',
            AbstractStorageFee: 'Title - Abstract Storage Fee',
            TitleInsuranceBinderFee: 'Title - Title Insurance Binder Fee',
            TitleCertFee: 'Title - Title Cert Fee',
            ErecordingFee: 'Title - E-recording Fee',
            "Rec/SvcFee": "Title - Recording Service Fee",
            TaxReview: 'Title - Tax Review',
            TitleCertOpinion: 'Title - Title Cert Opinion',
            CPLBuyer: 'Title - CPL Buyer',
            CPLSeller: 'Title - CPL Seller'
        };

        Object.keys(stateFeeData.Item).forEach(feeKey => {
          if (
            feeKey === 'StateCode' ||
            feeKey === 'SettlementFee' ||
            feeKey === 'SettlementFeeRefi'
          ) return;
        
          if (stateFeeData.Item[feeKey] == null || stateFeeData.Item[feeKey] === 0) return;
        
          // Abstractor Title Search — handle refi version if applicable
          if (feeKey === 'AbstractorTitleSearchREFI' && LoanPurposeType === 'Refinance') {
            extractedFees.push({
              FeeDescription: 'Title - Abstractor Title Search',
              BuyerFee: stateFeeData.Item[feeKey].toString(),
              SellerFee: '0.0'
            });
            return;
          }
        
          // Skip non-refi version of AbstractorTitleSearch on refinance
          if (feeKey === 'AbstractorTitleSearch' && LoanPurposeType === 'Refinance') return;
        
          extractedFees.push({
            FeeDescription: stateFeeTitles[feeKey] || feeKey,
            BuyerFee: stateFeeData.Item[feeKey].toString(),
            SellerFee: '0.0'
          });
        });

       // Exclude specific fees for Refinance LoanPurposeType
if (LoanPurposeType === 'Refinance' || LoanPurposeType === '$Refinance') {
    extractedFees = extractedFees.filter(fee => 
        fee.FeeDescription !== "Title - Owner's Title Insurance" && 
        fee.FeeDescription !== "Title - Sales Tax - Owner's Title Insurance" &&
        !fee.DisclosureItemName?.includes("Assignment") &&
        !fee.DisclosureItemName?.includes("Conveyance Deed")
    );
}

        // Calculate sum of BuyerFee's
        const totalBuyerFee = extractedFees.reduce((sum, fee) => sum + parseFloat(fee.BuyerFee), 0);

        // Extract LoanCommentText and remove HTML style tags
        const loanComment = loanComments.find(comment => comment['$']['xlink:label'] === 'RESPONSE_NOTE_1');
        let loanCommentText = loanComment ? loanComment.LoanCommentText[0] : '';
        loanCommentText = loanCommentText.replace(/<[^>]+>/g, ''); // Removing all HTML tags

        console.info('Extracted Fees:', extractedFees);
        console.info('Total Buyer Fee:', totalBuyerFee);
        console.info('Loan Comment Text:', loanCommentText);

        console.info('Preparing final response...');
        return {
            statusCode: 200,
            body: JSON.stringify({
                message: 'FNTEFees API called successfully',
                settlementFee: LoanPurposeType === 'Refinance'
                ? (stateFeeData.Item?.SettlementFeeRefi || 0)
                : (stateFeeData.Item?.SettlementFee || 0),
                stateCode: stateCode,
                city: city,
                county: countyName,
                rateCalcGuideResponse: extractedFees,
                totalBuyerFee: totalBuyerFee.toFixed(2), // Ensuring the fee is returned as a string with 2 decimal places
                loanCommentText: loanCommentText
            }),
        };
    } catch (error) {
        console.error('Error:', error.response ? error.response.data : error.message);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Failed to fetch OAuth token or call RateCalcGuide API', details: error.response ? error.response.data : error.message }),
        };
    }
};